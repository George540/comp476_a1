﻿using UnityEngine;

namespace AI
{
    public struct SteeringOutput
    {
        public Vector3 linear;
        public Quaternion angular;
    }
}
